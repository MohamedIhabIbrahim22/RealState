//We placed the functions related to admin
const Employees = require('../models/employees');

const getEmp=(req, res) => {
    Employees.find()
      .then(result => {
        res.render('viewAll', { employees: result, user: (req.session.user === undefined ? "" : req.session.user) });
      })
      .catch(err => {
        console.log(err);
      });
}
  
const addEmp=(req, res) => {
    const emp = new Employees({
      UserName: 'Mostafa',
      Password: '123',
      Image: 'aaa',
      Type: 'client'
    })
    emp.save()
      .then(result => {
        res.send(result);
      })
      .catch(err => {
        console.log(err);
      });
} 
  
const findEmp=(req, res) => { 
   Employees.findById('6649d794e7d44fafbe244882')
   .then(result => {
    res.send(result);
   })
   .catch(err => {
    console.log(err);
  })
}

module.exports={getEmp,addEmp,findEmp};